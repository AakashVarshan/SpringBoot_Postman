package com.spring.ex.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spring.ex.model.Employee;
import com.spring.ex.model.EmployeeDAO;

@RestController
public class EmployeeService {
	
	@RequestMapping("/hello")
    public String welcomepage() {
        return "hello to Spring REST Controller";
    }
	
    @RequestMapping(value="/findEmployee",method= RequestMethod.GET)
    public Employee homepage(@RequestBody Employee e) {
    	
    	EmployeeDAO eobj = new EmployeeDAO();
    	System.out.println(e.getEid());
        e = eobj.findTicket(e.getEid());
        System.out.println(e.getEid()+" "+e.getEname()+" "+e.getEdept());
        
        return e;
    }
    
    @RequestMapping(value="/addEmployee",method= RequestMethod.POST)
    public Employee addEmployee(@RequestBody Employee e) {
    	EmployeeDAO eobj = new EmployeeDAO();
     	e = eobj.addNewMovie(e.getEid(),e.getEname(),e.getEdept());
    	System.out.println("1 record Added successfully..!");
    	System.out.println(e.getEid()+" "+e.getEname()+" "+e.getEdept());
        return e;
    }
    
    @RequestMapping(value="/updateEmployee",method= RequestMethod.PUT)
    public Employee modifyEmployee(@RequestBody Employee e) {
    	
    	EmployeeDAO eobj = new EmployeeDAO();
        e = eobj.updateticket(e.getEdept(),e.getEid());
        System.out.println(e.getEid()+" "+e.getEname()+" "+e.getEdept());
    	return e;
    	
    }
    
    @RequestMapping(value="/removeEmployee",method= RequestMethod.DELETE)
    public Employee removeEmployee(@RequestBody Employee e) {
    	
    	EmployeeDAO eobj = new EmployeeDAO();
    	e=eobj.deleteticket(e.getEid());
    	System.out.println("1 record Deleted successfully..!");
        return e;
    }
    
    @RequestMapping(value="/add",method= RequestMethod.GET)
    public int add() {
    	int a =10;
    	int b = 20;
        return a+b;
    }
    

}
