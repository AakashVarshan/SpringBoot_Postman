package com.spring.ex.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





public class EmployeeDAO {
	
	
	public Employee addNewMovie(int id,String s2,String s3) {
		
		Employee store = new Employee();
		Connection cn = null;
		{
			int i = id;
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MOVIE_TICKET", "root", "admin");
			PreparedStatement st = cn.prepareStatement("INSERT INTO Employee(e_id,e_name,e_dept) VALUES(?,?,?)");
		    
			st.setInt(1, id);
			st.setString(2, s2);
			st.setString(3, s3);
			
			int r = st.executeUpdate();
            Statement s = cn.createStatement();
			ResultSet rs1 = s.executeQuery("Select *from Employee where e_id ="+i);
		
			rs1.next();
			store.setEid(rs1.getInt(1));
			store.setEname(rs1.getString(2));
			store.setEdept(rs1.getString(3));
			}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		return store;		
}
	
	public Employee findTicket(int id) {
		Employee store = new Employee();
		Connection cn = null;
		{
			int u = id;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MOVIE_TICKET", "root", "admin");
			Statement st = cn.createStatement ();
			ResultSet rs = st.executeQuery("select * from Employee where e_id = "+u);
			
			rs.next();
			store.setEid(rs.getInt(1));
			store.setEname(rs.getString(2));
			store.setEdept(rs.getString(3));
			
			}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return store;
	}
		
}
	public Employee deleteticket(int id) {
		Employee store = new Employee();
		Connection cn = null;
		{
			int u = id;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MOVIE_TICKET", "root", "admin");
			PreparedStatement st = cn.prepareStatement("delete from Employee where e_id = ?");
			st.setInt(1, u);
		    st.executeUpdate();
			}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
		return store;
}
	public  Employee updateticket(String dept,int id) {
		
		Employee store = new Employee();
		Connection cn = null;
		String n = dept;
		{
			int u = id;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");// register
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MOVIE_TICKET", "root", "admin");
			PreparedStatement st = cn.prepareStatement("UPDATE Employee SET e_dept = ? WHERE e_id = ?");
			st.setString(1, n);
			st.setInt(2, u);
			int result = st.executeUpdate();
			System.out.println(result);
			Statement st1 = cn.createStatement ();
			ResultSet rs = st.executeQuery("select * from Employee where e_id = "+u);
		
			rs.next();
			store.setEid(rs.getInt(1));
			store.setEname(rs.getString(2));
			store.setEdept(rs.getString(3));
			}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				}
			}
		}
		return store;
		}
	}
