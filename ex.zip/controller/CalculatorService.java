package com.spring.ex.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/calculator")

public class CalculatorService {
	
	@RequestMapping(value="/addEmployee",method= RequestMethod.GET)
	public int add(int a,int b) {
		return a+b;
	}

}
